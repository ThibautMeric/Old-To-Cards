Update Panel,Thumbnails and Well definition to Cards with Old-To-Cards.


